    <section class="about py-5">
        <div class="container py-md-5">
            <h3 class="tittle-wthree text-center">Contact Us</h3>
            <p class="sub-tittle text-center mt-4 mb-sm-5 mb-4"></p>
            <div class="row">

                <div class="col-lg-6 contact-info-left">
                    <ul class="list-unstyled w3ls-items">
                        <li>
                            <div class="row mt-5">
                                <div class="col-3">
                                    <div class="con-icon">
                                        <span class="fa fa-home"></span></div>
                                </div>
                                <div class="col-9">
                                    <h6>Address</h6>
                                    <p>kewin daniel
                                        <br>chennai,
                                        <br>Tamil Nadu. </p>
                                </div>
                            </div>
                        </li>

                        <li>
                            <div class="row mt-5">
                                <div class="col-3">
                                    <div class="con-icon">
                                        <span class="fa fa-envelope"></span></div>
                                </div>
                                <div class="col-9">
                                    <h6>Email</h6>
                                    <a href="kewindaniel460@gmail.com">kewindaniel460@gmail.com</a>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="row mt-5">
                                <div class="col-3">
                                    <div class="con-icon">
                                        <span class="fa fa-phone"></span> </div>
                                </div>
                                <div class="col-9">
                                    <h6>Phone</h6>
                                    <p>8012254197</p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-6 contact-right-wthree-info login">
                    <h5 class="text-center mb-4"></h5>
                    <form action="#" method="post">
                        <div class="form-group mt-4">
                            <label>Name</label>

                            <input type="text" class="form-control" id="validationDefault01" placeholder="" required="">
                        </div>
                        <div class="form-group mt-4">
                            <label>Eamil</label>
                            <input type="email" class="form-control" id="validationDefault02" placeholder="" required="">
                        </div>

                        <div class="form-group mt-4">
                            <label class="mb-2">Password</label>
                            <input type="password" class="form-control" id="password1" placeholder="" required="">
                        </div>
                        <div class="form-group mt-4">
                            <label class="mb-2">Message</label>
                            <textarea class="form-control" name="Message" placeholder="" required=""></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary submit mb-4">Submit </button>

                    </form>

                </div>
            </div>

            <div class="map-wthree mt-5 p-2">
               <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4013192.775893667!2d76.04399960232978!3d10.801080431880244!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b00c582b1189633%3A0x559475cc463361f0!2sTamil%20Nadu!5e0!3m2!1sen!2sin!4v1587783337888!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>
        </div>
    </section>