<?php
$current = '';
?>
<nav class="lavi-wthree">
                        <div id="logo">
                            <h1> <a class="navbar-brand" href="<?= $_SERVER['BASE_URL']; ?>">Tamilan Guru</a>
                            </h1>
                        </div>

                        <label for="drop" class="toggle">Menu</label>
                        <input type="checkbox" id="drop" />
                        <ul class="menu mr-auto">
                            <li class="<?= ($this->action == 'home') ? 'current' : ''; ?>"><a href="<?= $_SERVER['BASE_URL']; ?>">Home</a></li>
                            <li class="<?= ($this->action == 'about') ? 'current' : ''; ?>"><a href="<?= $_SERVER['BASE_URL']; ?>about">About</a></li>
                            <li>
                                <!-- First Tier Drop Down -->
                                
                            <li><a href="<?= $_SERVER['BASE_URL']; ?>contact">Contact</a>
                            <li class="log-vj ml-lg-5"><a href="<?= $_SERVER['BASE_URL']; ?>contact"><span class="fa fa-user-circle-o" aria-hidden="true"></span> Join</a>
                        </ul>
                    </nav>
