  <!-- about -->
    <section class="about py-5">
        <div class="container py-md-5">
            <div class="about-w3ls-info text-center mx-auto">
                <h3 class="tittle-wthree pt-md-5 pt-3">About Us</h3>
                <p class="sub-tittle mt-3 mb-sm-5 mb-4">Integer pulvinar leo id viverra feugiat. Pellentesque libero ut justo, semper at tempus vel, ultrices in ligula. Lorem ipsum dolor sit amet sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Sed do eiusmod tempor incididunt ut labore et dolore
                    magna
                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation</p>
                <a href="#" class="btn btn-primary submit">Read More</a>
            </div>
        </div>
    </section>
    <!-- //about -->
    <!-- /features -->
    <div class="welcome py-5" id="features">
        <div class="container py-xl-5 py-lg-3">
            <div class="row">
                <div class="col-lg-5 welcome-left">
                    <p>What We Provide</p>
                    <h3 class="tittle-wthree mt-2 mb-3">We Rank the Best
                        Courses on the Web</h3>

                    <p class="mt-4 pr-lg-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse porta erat sit amet eros
                        sagittis, quis
                        hendrerit
                        libero aliquam. Fusce semper augue ac dolor efficitur, a pretium metus pellentesque.</p>
                </div>
                <div class="col-lg-7 welcome-right text-center mt-lg-0 mt-5">
                    <div class="row">

                        <div class="col-sm-4 service-1-w3ls serve-gd2">
                            <div class="serve-grid mt-4">
                                <span class="fa fa-language s2"></span>
                                <p class="mt-2">Languages</p>
                            </div>
                            <div class="serve-grid mt-4">
                                <span class="fa fa-tachometer s3"></span>
                                <p class="mt-2">Software </p>
                            </div>
                        </div>
                        <div class="col-sm-4 service-1-w3ls serve-gd3">
                            <div class="serve-grid mt-4">
                                <span class="fa fa-handshake-o s4"></span>
                                <p class="mt-2">Business</p>
                            </div>
                            <div class="serve-grid mt-4">
                                <span class="fa fa-address-card-o s5"></span>
                                <p class="text-li mt-2">Coaching </p>
                            </div>
                            <div class="serve-grid mt-4">
                                <span class="fa fa-paint-brush s6"></span>
                                <p class="mt-2">Design </p>
                            </div>
                        </div>
                        <div class="col-sm-4 service-1-w3ls serve-gd2">
                            <div class="serve-grid mt-4">
                                <span class="fa fa-podcast s1"></span>
                                <p class="mt-2">Development </p>
                            </div>
                            <div class="serve-grid mt-4">
                                <span class="fa fa-book s7"></span>
                                <p class="mt-2">Literature</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- //features -->
    <!-- services -->
    <section class="services text-center py-5" id="services">
        <div class="container py-md-5">
            <h3 class="tittle-wthree text-center">Our Services</h3>
            <p class="sub-tittle text-center mt-4 mb-sm-5 mb-4">Sed do eiusmod tempor incididunt ut labore et dolore
                magna
                aliqua. Ut enim ad minim veniam, quis nostrud exercitation</p>
            <div class="row ser-sec-1">
                <div class="col-md-4 ser-w3pvt-gd-wthree">
                    <div class="icon">
                        <span class="fa fa-lightbulb-o s1"></span>
                    </div>
                    <!-- Icon ends here -->
                    <div class="service-content">
                        <h5> New Classes</h5>
                        <p class="serp">
                            Quisque sagittis lacus eu lorem sodalesd enean adipiscing.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 ser-w3pvt-gd-wthree">
                    <div class="icon">
                        <span class="fa fa-user s4"></span>
                    </div>
                    <!-- Icon ends here -->
                    <div class="service-content">
                        <h5>Expert Mentors</h5>
                        <p class="serp">
                            Quisque sagittis lacus eu lorem sodalesd enean adipiscing.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 ser-w3pvt-gd-wthree">
                    <div class="icon">
                        <span class="fa fa-question-circle s3"></span>
                    </div>
                    <!-- .Icon ends here -->
                    <div class="service-content">
                        <h5>Live Support</h5>
                        <p class="serp">
                            Quisque sagittis lacus eu lorem sodalesd enean adipiscing.
                        </p>
                    </div>
                </div>
            </div>
            <div class="row ser-sec-1">
                <div class="col-md-4 ser-w3pvt-gd-wthree">
                    <div class="icon">
                        <span class="fa fa-gift s6"></span>
                    </div>
                    <!-- Icon ends here -->
                    <div class="service-content">
                        <h5>Lifetime Access</h5>
                        <p class="serp">
                            Quisque sagittis lacus eu lorem sodalesd enean adipiscing.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 ser-w3pvt-gd-wthree">
                    <div class="icon">
                        <span class="fa fa-angellist s5"></span>
                    </div>
                    <!-- Icon ends here -->
                    <div class="service-content">
                        <h5>Membership</h5>
                        <p class="serp">
                            Quisque sagittis lacus eu lorem sodalesd enean adipiscing.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 ser-w3pvt-gd-wthree">
                    <div class="icon">
                        <span class="fa fa-folder-open-o s6"></span>
                    </div>
                    <!-- .Icon ends here -->
                    <div class="service-content">
                        <h5>25000+ Courses</h5>
                        <p class="serp">
                            Quisque sagittis lacus eu lorem sodalesd enean adipiscing.
                        </p>
                    </div>
                </div>
            </div>
            <div class="row ser-sec-1">
                <div class="col-md-4 ser-w3pvt-gd-wthree border-bottom-0 bottom-vj-gds">
                    <div class="icon">
                        <span class="fa fa-black-tie s3"></span>
                    </div>
                    <!-- Icon ends here -->
                    <div class="service-content">
                        <h5>Law & Ethic</h5>
                        <p class="serp">
                            Quisque sagittis lacus eu lorem sodalesd enean adipiscing.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 ser-w3pvt-gd-wthree border-bottom-0 bottom-vj-gds">
                    <div class="icon">
                        <span class="fa fa-music s2"></span>
                    </div>
                    <!-- Icon ends here -->
                    <div class="service-content">
                        <h5>Art and Music</h5>
                        <p class="serp">
                            Quisque sagittis lacus eu lorem sodalesd enean adipiscing.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 ser-w3pvt-gd-wthree border-bottom-0">
                    <div class="icon">
                        <span class="fa fa-bar-chart s7"></span>
                    </div>
                    <!-- .Icon ends here -->
                    <div class="service-content">
                        <h5>Data Scientist</h5>
                        <p class="serp">
                            Quisque sagittis lacus eu lorem sodalesd enean adipiscing.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //services -->
   