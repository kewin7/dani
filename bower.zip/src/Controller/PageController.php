<?php

namespace App\Controller;

use System\BaseController;

/**
 * Description of PageController
 *
 * @author gift
 */
class PageController extends BaseController {

    public $action;

    public function __construct($action) {
        parent::__construct();
        $this->action = $action;
    }

    public function action404() {
        $this->render('404');
    }
    
public function actionAbout() {
   
        $this->tags->title($this->params['about']['title']);
        $this->tags->meta('keywords', $this->params['about']['keywords']);
        $this->tags->meta('description', $this->params['about']['description']);
        $this->render('about');
    }
    
    public function actionContact() {
        $this->tags->title($this->params['contact']['title']);
        $this->tags->meta('keywords', $this->params['contact']['keywords']);
        $this->tags->meta('description', $this->params['contact']['description']);
        $this->render('contact');
    }

    

    

    
    public function actionSendmail() {
        // Read the form values
        $success = false;
        $senderName = isset($_POST['name']) ? preg_replace("/[^\.\-\' a-zA-Z0-9]/", "", $_POST['name']) : "";
        $senderEmail = isset($_POST['email']) ? preg_replace("/[^\.\-\_\@a-zA-Z0-9]/", "", $_POST['email']) : "";
        $senderPhone = isset($_POST['phone']) ? preg_replace("/[^\.\-\' a-zA-Z0-9]/", "", $_POST['phone']) : "";
        $subject = isset($_POST['subject']) ? preg_replace("/[^\.\-\' a-zA-Z0-9]/", "", $_POST['subject']) : "";
        $message = isset($_POST['message']) ? preg_replace("/(From:|To:|BCC:|CC:|Subject:|Content-Type:)/", "", $_POST['message']) : "";

// If all values exist, send the email
        if ($senderName && $senderEmail && $message) {
            $recipient = '4D' . " <" . 'prabhu@nexifysoftware.com' . ">";
            $headers = "From: " . $senderName . " <" . $senderEmail . ">";
            $mailBody = 'Sender Name: ' . $senderName . "\r\n" . 'Sender Email: ' . $senderEmail . "\r\n" . 'Sender Phone: ' . $senderPhone . "\r\n" . 'Subject: ' . $subject . "\r\n" . 'Message: ' . $message;
            $success = mail($recipient, $subject, $mailBody, $headers);
            echo "<p class='success'>Thanks for contacting us. We will contact you ASAP!</p>";
        }
    }

}
