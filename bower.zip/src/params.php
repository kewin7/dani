<?php

return [
    'home' => [
        'title' => 'Tamilan Guru | Home ',
        'keywords' => '',
        'description' => ''
    ],
    'about' => [
        'title' => 'Tamilan Guru | About Us',
        'keywords' => '',
        'description' => '',
    ],
     'contact' => [
        'title' => 'Tamilan Guru | Contact Us',
        'keywords' => '',
        'description' => '',
    ],
    'social_media' => [
        'facebook' => 'https://www.facebook.com/4D-Interiors-130643400825972',
        'gplus' => '',
        'twitter' => '',
    ],
    'contacts' => [
        'mobile_no' => '+91 909291 5290, +91 888300 2888',
        'address' => '75/81-7, St Pauls Road, <br> 
                                    Railway Feeder Road,<br> 
                                    Maharaja Nagar, Tirunelveli - 627011',
        'email' => '4dinteriors.nellai@gmail.com',
    ],
];
