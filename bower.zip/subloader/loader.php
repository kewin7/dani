<?php
/**
 * Description of PageController
 *
 * @author kewindaniel
 */
$assets = [
    'css' => [
        'subloader/design/bootstrap.css',
        'subloader/design/style.css',
        'subloader/design/font-awesome.css'
        
    ],
    'js' => [
       
    ]
];

return $assets;