<section class="page-banner" style="background-image:url(images/background/page-banner-bg.jpg);">
    <div class="auto-container">
        <h1>404 Page</h1>
    </div>
</section>


<section class="container contact-us clearfix text-center">
    <div class="inner-oops" >
        	 <h3 style="
    line-height: 40px;
"> Oops</h3>
                    <h1 style="
    line-height: 100px;
"> 404 </h1>
                          <h2>Page Not Present</h2>
                          
                          <h4><a href="/"> Back to Home Page </a></h4>
        </div>
   	</section>