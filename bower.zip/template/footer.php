 <div class="copy_right p-3 d-flex justify-content-around">

        <p>© 2020 TamilanGuru. All rights reserved | Design by
            <a href="#">Kewin daniel</a>

        </p>
        <!-- move top -->
        <div class="move-top">
            <a href="#home" class="move-top">
                <span class="fa fa-angle-double-up mt-3" aria-hidden="true"></span>
            </a>
        </div>
        <!-- move top -->
    </div>
</body>
</html>
