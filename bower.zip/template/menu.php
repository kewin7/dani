<?php
$current = '';
$servies = ['imported-wallpaper', 'false-ceiling', 'partition-works', 'curtain-works', 'modular-kitchen', 'vinyl-wooden-flooring', 'all-blinds', 'acp-works', 'teflon-glass', 'upvc-windows', 'ss-works', '3d-flooring'];
if (in_array($this->action, $servies)) {
    $current = 'current';
}
?>
<div class="navbar-collapse collapse clearfix">                                                                                              
    <ul class="nav navbar-nav navbar-right">
        <li class="<?= ($this->action == 'home') ? 'current' : ''; ?> dropdown"><a href="<?= $_SERVER['BASE_URL']; ?>" title="">Home</a></li>
        <li class="<?= ($this->action == 'about-us') ? 'current' : ''; ?>"><a href="<?= $_SERVER['BASE_URL']; ?>about-us" title="">About Us</a></li>
        <li class=" <?= $current; ?> dropdown"><a href="#" title="">Our Services</a>
            <ul class="submenu">
                <li><a href="<?= $_SERVER['BASE_URL']; ?>imported-wallpaper" title="">Imported Wallpapers</a></li>
                <li><a href="<?= $_SERVER['BASE_URL']; ?>false-ceiling" title="">False Ceiling</a></li>
                <li><a href="<?= $_SERVER['BASE_URL']; ?>partition-works" title="">Partition Works</a></li>
                <li><a href="<?= $_SERVER['BASE_URL']; ?>curtain-works" title="">Curtain Works</a></li>
                <li><a href="<?= $_SERVER['BASE_URL']; ?>modular-kitchen" title="">Modular  kitchen</a></li>
                <li><a href="<?= $_SERVER['BASE_URL']; ?>vinyl-wooden-flooring" title="">Vinyl | Wooden Flooring</a></li>
                <li><a href="<?= $_SERVER['BASE_URL']; ?>all-blinds" title="">All Blinds</a></li>
                <li><a href="<?= $_SERVER['BASE_URL']; ?>acp-works" title="">ACP Works</a></li>
                <li><a href="<?= $_SERVER['BASE_URL']; ?>teflon-glass" title="">Teflon Glass</a></li>
                <li><a href="<?= $_SERVER['BASE_URL']; ?>upvc-windows" title="">UPVC Windows</a></li>
                <li><a href="<?= $_SERVER['BASE_URL']; ?>ss-works" title="">SS Works</a></li>
                <li><a href="<?= $_SERVER['BASE_URL']; ?>3d-flooring" title="">3D Flooring</a></li>

            </ul>
        </li>
        <li class="<?= ($this->action == 'gallery') ? 'current' : ''; ?>"><a href="<?= $_SERVER['BASE_URL']; ?>gallery" title="">Gallery</a></li>

        <li class="<?= ($this->action == 'contact-us') ? 'current' : ''; ?>"><a href="<?= $_SERVER['BASE_URL']; ?>contact-us" title="">Contact Us</a></li>
    </ul>
    <div class="clearfix"></div>
</div>