<!DOCTYPE html>
<html lang="zxx">

<head>
    
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8" />
    <meta name="keywords" content="EduWily Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    
    <!-- //Meta tag Keywords -->
   
    <!-- //font-awesome-icons -->
    <!-- /Fonts -->
    <link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Playfair+Display:400,400i,700,700i,900,900i" rel="stylesheet">
    <!-- //Fonts -->
</head>

<body>
    <!-- home -->
    <div id="home" class="inner-w3pvt-page">
        <div class="overlay-innerpage">
            <!-- banner -->
            <div class="top_w3pvt_main container">

                <!-- nav -->
                <div class="nav_w3pvt text-center">
                    <!-- nav -->
                    <nav class="lavi-wthree">
                        <div id="logo">
                            <h1> <a class="navbar-brand" href="index.html">EduWily</a>
                            </h1>
                        </div>

                        <label for="drop" class="toggle">Menu</label>
                        <input type="checkbox" id="drop" />
                        <ul class="menu mr-auto">
                            <li><a href="<?= $_SERVER['BASE_URL']; ?>">Home</a></li>
                            <li class="active"><a href="<?= $_SERVER['BASE_URL']; ?>about">About</a></li>
                            <li>
                                <!-- First Tier Drop Down -->
                                <label for="drop-2" class="toggle">Drop Down<span class="fa fa-angle-down" aria-hidden="true"></span> </label>
                                <a href="#">Drop Down <span class="fa fa-angle-down" aria-hidden="true"></span></a>
                                <input type="checkbox" id="drop-2" />
                                <ul>
                                    <li><a href="#features">Features</a>
                                    </li>
                                    <li><a href="#services">Services</a>
                                    </li>
                                    <li><a href="#gallery">Gallery</a>
                                    </li>
                                    <li><a href="#test">Testimonials</a>
                                    </li>
                                    <li><a href="under.html">Blogs</a>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="contact.html">Contact</a>
                            <li class="log-vj ml-lg-5"><a href="<?= $_SERVER['BASE_URL']; ?>contact"><span class="fa fa-user-circle-o" aria-hidden="true"></span> Join</a>
                        </ul>
                    </nav>
                    <!-- //nav -->
                </div>
            </div>
            <!-- //nav -->

        </div>
        <!-- //banner -->
    </div>